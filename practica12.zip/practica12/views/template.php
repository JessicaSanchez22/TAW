<!--Es la plantilla que vera el usuario al ejecutar la aplicación -->
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Template</title>
	<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">


	<style>
		table {
		    margin: 8px;
		}

		th {
		    font-family: Verdana, fantasy;
		    font-size: 20px;
		    background: #2F9DC6;
		    color: #FFF;
		    padding: 2px 6px;
		    border-collapse: separate;
		    border: 1px solid #000;
		}

		td {
		   font-family: Verdana, fantasy;
		    font-size: 20px;
		    border: 1px solid #DDD;
		}

		section{
			position: relative;
			margin: auto;
			width:400px;
		}

		section h1{
			position: relative;
			margin: auto;
			padding:10px;
			text-align: center;
		}

		section form{
			position:relative;
			margin:auto;
			width:400px;
		}

		section form input{
			display:inline-block;
			padding:10px;
			width:95%;
			margin:5px;
		}

		section form input[type="submit"]{
			position:relative;
			margin:20px auto;
			left:4.5%;

		}

		select{
			font-family: Verdana, fantasy;
		    font-size: 20px;
			background:#EDBAA6;
			color: white;
		}

		#registro{
  font-size: 35px;
  text-align: center;
  margin-bottom: 25px;
  font-weight: 300;
  a {
    color: #444;
  }
}

.login-page,
.register-page {
  background: $gray-200;
}

#login-box,
#register-box {
  width: 360px;
  margin: 7% auto;
  @media (max-width: map-get($grid-breakpoints, sm)) {
    width: 90%;
    margin-top: 20px;
  }
}

.login-box-body,
.register-box-body {
  background: $white;
  padding: 20px;
  border-top: 0;
  color: #666;
  .form-control-feedback {
    color: #777;
  }
}

.login-box-msg,
.register-box-msg {
  margin: 0;
  text-align: center;
  padding: 0 20px 20px 20px;
}

.social-auth-links {
  margin: 10px 0;
}

	</style>

</head>

<body>

<section>

<?php 

$mvc = new MvcController();
$mvc -> enlacesPaginasController();

 ?>

</section>
	
</body>

</html>